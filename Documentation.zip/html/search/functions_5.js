var searchData=
[
  ['operator_2b_33',['operator+',['../classVector.html#a5175e5e33d8e5f78aa50a6ab465be76a',1,'Vector']]],
  ['operator_2d_34',['operator-',['../classVector.html#a0ceba781eecf1ac46a7768266e5388ba',1,'Vector']]]
];
