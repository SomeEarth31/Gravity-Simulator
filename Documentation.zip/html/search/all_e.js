var searchData=
[
  ['x_19',['x',['../classVector.html#ae3c7f1a3b3e0023ac439f63cf4c61569',1,'Vector::x(double x)'],['../classVector.html#a3c5cde648edd14484f212199037f16a8',1,'Vector::x(void) const']]]
];
